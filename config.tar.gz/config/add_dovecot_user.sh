#!/bin/bash
# $1 - user name
# $2 - password
users='/etc/dovecot/users'
if [ ! -z $1 ];then
    user_name=$1
else
    echo -n 'Please enter username: '
    read
    user_name=$REPLY
    echo $user_name
fi
if [ ! -z $2 ];then
    password=$2
else
    echo -n 'Please enter password: '
    read
    password=$REPLY
    echo $password
fi

sha512=$(/usr/bin/doveadm pw -s SHA512-CRYPT -u $user_name -p $password)
user="$user_name@172.16.0.5:$sha512::::::"

echo $user >> $users

test=$(doveadm auth test -x service=smtp -x rip=172.16.0.5 $user_name@172.16.0.5 $password)
echo $test
echo -e "Creating user $user_name@172.16.0.5 done\n"
exit 0

