#!/bin/bash
path='config'
# установка необходимы утилит
echo "Test network..."
if ping vk.com -c 2 -q -W 3 > /dev/null 2>&1;then
    echo "Network is configured successfully"
else
    echo "Erorr while ping vk.com, check network config!!"
fi
echo "Установка программ"
apt -y install dovecot-core dovecot-pop3d exim4-daemon-heavy apache2 vsftpd
echo "Создание пользователя vmail"
#Создание пользователя, от имени которого будет работать Dovecot
groupadd -g 1100 -r vmail
useradd -g 1100 -r -u 1100 vmail
mkdir /home/vmail
chown vmail:vmail /home/vmail
chmod u=rwx,g=rx,o= /home/vmail
usermod -aG dovecot Debian-exim
cp dovecot_log /etc/logrotate.d/dovecot
usermod -aG dovecot Debian-exim
systemctl restart rsyslog.service
echo "Копирование dovecot files"
cp -Rf "$path/dovecot" /etc/dovecot
chown -R :dovecot /etc/dovecot
echo "Копирование exim4 files"
cp -Rf "$path/exim4" /etc/exim4
chown -R :Debian-exim /etc/exim4
echo "Создание пользователей"
declare -a users_list=("in1" "in2" "out1" "out2")
for u in "${users_list[@]}"; do
    bash add_dovecot_user.sh $u 123
done

systemctl restart dovecot.service exim4.service
systemctl enable dovecot.service exim4.service vsftpd apache2
echo "Настройка ftp сервера"
# Настройка ftp сервера
adduser ftpuser
sudo mkdir -p /home/ftpuser/ftpdir
sudo chmod -R 750 /home/ftpuser/ftpdir
sudo chown ftpuser: /home/ftpuser/ftpdir
echo ftpuser > /etc/vsftpd.user_list
cp "$path/vsftpd.conf" /etc/vsftpd.conf
systemctl restart vsftpd

echo "Need reboot system"
